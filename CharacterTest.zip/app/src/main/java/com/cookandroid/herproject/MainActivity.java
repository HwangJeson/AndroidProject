package com.cookandroid.herproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView pic1, pic2, pic3, pic4;

    Button btnOK;
    int A = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("성격테스트");

        ImageView image[] = new ImageView[4];
        Integer imageId[] = { R.id.image1,  R.id.image2, R.id.image3, R.id.image4 };

        final int imgName[] = {1, 2, 3, 4 };


        for (int i=0; i < imageId.length; i++) {
            final int index;
            index = i;
            image[index] = (ImageView) findViewById(imageId[index]);

            image[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   /* Toast.makeText(getApplicationContext(), imgName[index] + "번 그림 선택",
                            Toast.LENGTH_SHORT).show();*/

                     A = imgName[index];

                    Toast.makeText(getApplicationContext(), A + "번 그림 선택",
                            Toast.LENGTH_SHORT).show();
                }
            });

            Button btnFinish = (Button) findViewById(R.id.btnOK);
            btnFinish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
                    intent.putExtra("ImageName", A);
                    startActivity(intent);
                }
            });
        }

    }
}