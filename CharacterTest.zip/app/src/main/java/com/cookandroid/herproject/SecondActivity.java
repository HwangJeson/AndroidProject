package com.cookandroid.herproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    ImageView image;

    TextView textA, textB, textC, textContents;

    Button btnReplay, btnEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);

        setTitle("CharacterTest");

        image = (ImageView) findViewById(R.id.image);

        textA = (TextView) findViewById(R.id.textA);
        textB = (TextView) findViewById(R.id.textB);
        textC = (TextView) findViewById(R.id.textC);
        textContents = (TextView) findViewById(R.id.textContents);

        btnReplay = (Button) findViewById(R.id.btnReplay);
        btnEnd = (Button) findViewById(R.id.btnEnd);

        Intent intent = getIntent();

        int img = intent.getExtras().getInt("ImageName");

        switch (img) {
            case  1 :
                image.setImageResource(R.drawable.pic1);
                textA.setText("내성적인(Introspective)");
                textB.setText("민감한(Sensitive)");
                textC.setText("사려깊은(Considerate)");
                textContents.setText("당신은 자신과 환경에 대해 평균에 비해 많은 고민이 있는 편입니다. 다른 사람들과 이런 저런 잡담을 하기보다는 혼자 카페에가서 커피를 마신다거나, 드라이브를 하면서 음악을 듣는 것을 좋아합니다. 당신은 친구를 매우 주의깊게 사귀는데, 이로 인해 내적 평화와 안정감을 얻습니다. 그렇지만 당신은 아무리 혼자있더라도 조금도 지루함을 느끼지 않는 성격입니다.");
                break;
            case  2 :
                image.setImageResource(R.drawable.pic2);
                textA.setText("독립적인(Independent)");
                textB.setText("얽매이지 않는(Unconventional)");
                textC.setText("속박을 싫어하는(Unfettered)");
                textContents.setText("당신은 스스로 자신의 인생의 방향을 선택할 수 있습니다. 자유롭게 얽매이지 않기를 바라고 있습니다. 이것은 당신의 직장생활 또는 여가 활동, 심지어는 공부까지도 예술가적 성향을 나타냅니다. 당신이 가지고 있는 자유에 대한 열망은 때때로 사람들이 바라는 것과 정반대의 결과를 낳기도 합니다. 당신의 라이프 스타일은 매우 개성적이기 때문에 유행을 따라하지 않습니다.");
                break;
            case  3 :
                image.setImageResource(R.drawable.pic3);
                textA.setText("역동적인(Dynamic)");
                textB.setText("활동적인(Active)");
                textC.setText("외향적인(Extroverted)");
                textContents.setText("당신은 재미를 느끼고 다양한 경험을 한다면, 위험을 감수하고서라도 그 일에 빠져들기를 서슴치 않아하는 사람입니다. 일상적인 것은 당신에게 그저 무미건조한 것에 지나지 않습니다. 당신은 무슨일이든지 주도적으로 하길 좋아하고, 그렇게 할 때 당신의 진취적인 성격은 더욱 빛을 발합니다.");
                break;
            case  4 :
                image.setImageResource(R.drawable.pic4);
                textA.setText("현실적인(Down to Earth)");
                textB.setText("균형잡힌(Well-Balanced)");
                textC.setText("잘 어울리는(Harmonious)");
                textContents.setText("당신은 이상보다는 일상생활에 비중을 두고 있으며, 복잡하게 얽히는 사랑보다는 평범한 사람을 추구합니다. 모든 문제를 현실적인 바탕 위에서 생각하기 때문에 주변 사람들은 당신 덕분에 현실감각을 느끼는 물론, 여유로움을 느끼게 됩니다. 따라서 당신은 주위 사람들로부터 따듯하고 인간적인 사람으로 인정받고 있습니다. 옷입는 것 역시 실용적이면서도 단정하고 품위 있게 입기를 좋아하는 타입니다.");
                break;
        }

        btnReplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });

    }
}